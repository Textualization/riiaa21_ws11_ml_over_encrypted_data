#define WITH_BE2
#define WITH_BE4
/* #undef WITH_NTL */
/* #undef WITH_TCM */

#define HAVE_INT128 TRUE
#define HAVE_INT64 TRUE
#define NATIVEINT 64
#define CKKS_M_FACTOR 1
